import { Chapter2 } from "@/components/chapters/chapter-2"

export default function Module2Page() {
  return <Chapter2 />
}
