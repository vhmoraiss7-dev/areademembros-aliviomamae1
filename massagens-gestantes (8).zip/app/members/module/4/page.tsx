import { Chapter4 } from "@/components/chapters/chapter-4"

export default function Module4Page() {
  return <Chapter4 />
}
