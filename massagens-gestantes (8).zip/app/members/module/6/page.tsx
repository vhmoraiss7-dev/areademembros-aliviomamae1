import { Chapter5 } from "@/components/chapters/chapter-5"

export default function Module6Page() {
  return <Chapter5 />
}
