import { MembersDashboard } from "@/components/members-dashboard"

export default function MembersPage() {
  return <MembersDashboard />
}
