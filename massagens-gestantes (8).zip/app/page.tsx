import { MembersDashboard } from "@/components/members-dashboard"

export default function HomePage() {
  return <MembersDashboard />
}
